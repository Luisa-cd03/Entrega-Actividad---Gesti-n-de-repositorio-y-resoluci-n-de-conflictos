

function listUsers(req, res) {
  
  res.json({ message: "Listado de usuarios (simulado)" });
}

function createUser(req, res) {
  
  res.status(201).json({ message: "Usuario creado (simulado)" });
}

module.exports = { listUsers, createUser };

