# Comandos ejecutados
cd "C:\Users\Jesus Mejia\Desktop\LuisaCapa\luisacapa"
git init
git branch -M main
git config user.name "Luisa Capachero"
git config user.email "luisacapachero0305@gmail.com"
git add .
git commit -m "chore: estructura inicial del proyecto"
Set-Content README.md ...
git add README.md
git commit -m "docs: actualizar README..."
git switch -c feature/user-controller
Add-Content src/controllers/user.controller.js ...
git add ...
git commit -m "feat(user-controller):..."
git switch main
git merge feature/user-controller
